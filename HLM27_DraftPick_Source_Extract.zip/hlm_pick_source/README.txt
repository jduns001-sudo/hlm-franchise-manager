HLM 27 Draft Pick Source Extract

Source: roster2026926000 (1).hlr
Extracted from the HLR ZIP archive without altering source records.

Files included:
- Picks.txt: 224 records
- Custom/Picks.txt: 330 records
- Teams.txt: 277 records
- Trades.txt: 3,832 lines

Picks.txt + Custom/Picks.txt = 554 draft-pick records.

Pittsburgh is Team ID 5 in Teams.txt.

IMPORTANT:
The five comma-separated values in the pick records have NOT been relabeled here. Copilot must inspect/verify their exact semantics from the HLM source data before implementing the importer.

Observed examples from Custom/Picks.txt include:
0,26,28,5,3
0,26,16,5,7
0,27,3,5,4
These contain Pittsburgh (5) in the fourth field, but field meaning must be verified from HLM data rather than assumed.

Do not manufacture records. Preserve source records exactly and determine ownership semantics before coding.
